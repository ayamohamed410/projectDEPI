/*import 'package:flutter/material.dart';
import '/core/theme/app_styles.dart';
import '../widgets/container.dart';


//colors
//softBlueTint
// iconbluebg
//bluenewcontainer
class TechnicianChat extends StatefulWidget {
  final String? jobId;
const TechnicianChat({super.key, this.jobId});
//  const TechnicianChat({super.key}); //*********************************************************************************************** */

  @override
  State<TechnicianChat> createState() => _TechnicianChatState();
}

class _TechnicianChatState extends State<TechnicianChat> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC), 
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          onPressed: () {},
          icon: const Icon(
            Icons.arrow_back_ios_new,
            color: Colors.black,
            size: 20,
          ),
        ),
        title: const Text(
          "Technician Chat",
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16.0),
            child: CircleAvatar(
              radius: 18,
              backgroundColor: Colors.black,
              child: Icon(Icons.person, color: Colors.white, size: 20),
            ),
          ),
        ],
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            //1 widjet
            buildCustomContainer(
              child: Column(
                children: [
                  Row(
mainAxisAlignment: MainAxisAlignment.spaceBetween,

                    children: [


Row(children: [
                      Icon(Icons.person, size: 50),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text(
                                'Tarek Mansour',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(width: 8),
                              buildCustomContainer(
                                cardColor: AppColors.iconbluebg,
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.verified,
                                      size: 12,
                                      color: Colors.black,
                                    ),
                                    SizedBox(width: 4),
                                    Text(
                                      'Client',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),

                          Row(
                            children: const [
                              Icon(
                                Icons.star_border,
                                size: 14,
                                color: Colors.grey,
                              ),
                              SizedBox(width: 2),
                              Text(
                                'Cairo • Frequent Customer (4.9 ★)',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      ],)

                      , CircleAvatar(
    backgroundColor: Colors.blue.shade50,
    radius: 22,
    child: IconButton(
      icon: const Icon(Icons.phone_outlined, color: Colors.blue, size: 20),
      onPressed: () {
        // إجراء الاتصال هنا
      },
    ),
  ),
                    ],
                  ),

                  //containerblue
                  buildCustomContainer(
                    cardColor: AppColors.bluenewcontainer,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        //icon
                        buildCustomContainer(
                          decoration: BorderRadiusGeometry.circular(16),
                          cardColor: AppColors.iconbluebg,
                          child: const Icon(
                            Icons.handyman,
                            size: 30,
                            color: Colors.blue,
                          ),
                        ),

                        const SizedBox(width: 6),
                        Column(
                          children: [
                            Row(
                              children: [
                                const Text(
                                  'Job #7H-9482',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                    color: Colors.black87,
                                  ),
                                ),

                                const SizedBox(width: 6),
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: const BoxDecoration(
                                    color: Colors.blue,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                const Text(
                                  'In Progress',
                                  style: TextStyle(
                                    color: Colors.blue,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Apt 402, South Teseen St, New C...',
                              style: TextStyle(
                                color: AppColors.textSecondary,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                        OutlinedButton(
                          onPressed: () {
                            // الانتقال لصفحة تفاصيل الوظيفة
                          },
                          style: OutlinedButton.styleFrom(
                            backgroundColor: Colors.white,
                            side: BorderSide(color: Colors.grey.shade300),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                          ),
                          child: const Text(
                            'Job Details →',
                            style: TextStyle(color: Colors.black, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  buildCustomContainer(
                    cardColor: AppColors.bluenewcontainer,
                    child: Row(
                      children: [
                        Icon(
                          Icons.shield_outlined,
                          color: AppColors.primary,
                          size: 20,
                        ),

                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                            'Official 7elhaly chat channel. Retain all service updates here for warranty validation & job documentation.',
                            style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  ListView(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      Column(crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          buildCustomContainer(child: Text("Today, October 24",),cardColor: AppColors.bluenewcontainer) ,
                        ],
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: buildCustomContainer(
                          cardColor: Colors.black,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 250,
                                child: Text(
                                  maxLines: 10,
                                  overflow: TextOverflow.clip,
                                  'Hello Mr. Tarek, I have accepted your request and I am en route with the replacement compression valves.',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                  ),
                                ),
                              ),

                              const SizedBox(height: 4),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: const [
                                  Text(
                                    '10:34 AM',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 10,
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(
                                    Icons.done_all,
                                    color: Colors.blue,
                                    size: 14,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                      Row(
                        children: [
                          Icon(Icons.person, size: 40),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: buildCustomContainer(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: 250,
                                    child: Text(
                                      maxLines: 10,
                                      overflow: TextOverflow.clip,
                                      "Thanks Mahmoud! Please note the building elevator is on the right side of the main lobby.",
                                    ),
                                  ),

                                  const SizedBox(height: 4),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: const [
                                      Text(
                                        '10:34 AM',
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 10,
                                        ),
                                      ),
                                      SizedBox(width: 4),
                                      Icon(
                                        Icons.done_all,
                                        color: Colors.blue,
                                        size: 14,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: buildCustomContainer(
                          cardColor: Colors.black,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(Icons.person, size: 50, color: Colors.white),
                              SizedBox(
                                width: 250,
                                child: Text(
                                  maxLines: 10,
                                  overflow: TextOverflow.clip,
                                  'I have the standard brass joints ready. Arriving in ~15 minutes.',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                  ),
                                ),
                              ),

                              const SizedBox(height: 4),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: const [
                                  Text(
                                    '10:43 AM',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 10,
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(
                                    Icons.done_all,
                                    color: Colors.blue,
                                    size: 14,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                      Row(
                        children: [
                          Icon(Icons.person, size: 40),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: buildCustomContainer(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width: 250,
                                    child: Text(
                                      maxLines: 10,
                                      overflow: TextOverflow.clip,
                                      'Perfect, the front gate is open.',
                                    ),
                                  ),

                                  const SizedBox(height: 4),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: const [
                                      Text(
                                        '10:45 AM',
                                        style: TextStyle(
                                          color: Colors.grey,
                                          fontSize: 10,
                                        ),
                                      ),
                                      SizedBox(width: 4),
                                      Icon(
                                        Icons.done_all,
                                        color: Colors.blue,
                                        size: 14,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                        
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.flash_on,
                                    size: 16,
                                    color: Colors.blue,
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    'QUICK STATUS UPDATES',
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),SizedBox(width: 100,),
                              Text(
                                'Tap to send',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.blue,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                ActionChip(
                                  avatar: const Icon(
                                    Icons.location_on,
                                    size: 16,
                                    color: Colors.blue,
                                  ),
                                  label: const Text(
                                    'I have arrived at the building',
                                  ),
                                  backgroundColor: AppColors.bluenewcontainer,
                                  onPressed: () {},
                                ),

                                const SizedBox(width: 8),
                                ActionChip(
                                  avatar: const Icon(
                                    Icons.check_circle,
                                    size: 16,
                                    color: Colors.blue,
                                  ),
                                  label: const Text('Work completed'),
                                  backgroundColor: AppColors.bluenewcontainer,
                                  onPressed: () {},
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            buildCustomContainer(
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.camera_alt_outlined,
                      color: Colors.grey,
                    ),
                    onPressed: () {},
                  ),
                  IconButton(
                    icon: const Icon(
                      Icons.insert_drive_file_outlined,
                      color: Colors.grey,
                    ),
                    onPressed: () {},
                  ),
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Reply to Tarek Mansour',
                        hintStyle: const TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                        filled: true,
                        fillColor: AppColors.bluenewcontainer,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.mic_none, color: Colors.grey),
                          onPressed: () {},
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    backgroundColor: Colors.black,
                    radius: 22,
                    child: IconButton(
                      icon: const Icon(
                        Icons.send,
                        color: Colors.white,
                        size: 18,
                      ),
                      onPressed: () {},
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
*/

import 'package:final_depi/features/Technician/presentation/bloc/chat/chat_event.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart' as intl;
import 'package:flutter/services.dart';
import '/core/theme/app_styles.dart';
import '../widgets/container.dart';
import '../../../jobs/jobs_repository.dart';

import '../bloc/chat/chat_bloc.dart';
import '../../dev/seed_chat.dart';
class TechnicianChat extends StatelessWidget {
  final String? jobId;
  const TechnicianChat({super.key, this.jobId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ChatBloc(JobsRepository())..add(LoadChatDataEvent(jobId)),
      // هنا بنمرر الـ jobId للـ View عشان يقدر يشوفه جوا الـ State
      child: _TechnicianChatView(jobId: jobId),
    );
  }
}

class _TechnicianChatView extends StatefulWidget {
  final String? jobId; // 1. عرّفنا المتغير هنا
  const _TechnicianChatView({this.jobId}); // 2. استقبلناه في الكونستركتور

  @override
  State<_TechnicianChatView> createState() => _TechnicianChatViewState();
}

class _TechnicianChatViewState extends State<_TechnicianChatView> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }


  void _scrollToBottom() {
    
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
  0.0,
  duration: const Duration(milliseconds: 300),
  curve: Curves.easeOut, // <-- ضيفي دي وهيتحل الإيرور فوراً
);
    
    }
  }

  void _showCallDialog(String? phone) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Customer Phone'),
        content: Text(phone != null && phone.isNotEmpty ? phone : 'No phone number available'),
        actions: [
          if (phone != null && phone.isNotEmpty)
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: phone));
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Phone number copied to clipboard')),
                );
              },
              child: const Text('Copy'),
            ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChatBloc, ChatState>(
      listener: (context, state) {
        if (state.error != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.error!), backgroundColor: Colors.red),
          );
        }
      },
      builder: (context, state) {
        if (state.isLoading) {
          return Scaffold(
            backgroundColor: const Color(0xFFF8FAFC),
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              leading: IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black, size: 20),
              ),
              title: const Text("Technician Chat", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18)),
            ),
          body: const Center(child: CircularProgressIndicator()),
          );
        }

        // في حال عدم وجود أوردر نشط
        if (state.job == null) {
          return Scaffold(
            backgroundColor: const Color(0xFFF8FAFC),
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              leading: IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black, size: 20),
              ),
              title: GestureDetector(
                onLongPress: kDebugMode ? () async {
                  await SeedChat.seed();
                  if (context.mounted) {
                    context.read<ChatBloc>().add(const LoadChatDataEvent(null));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Chat Seed Data Loaded Successfully!')),
                    );
                  }
                } : null,
                child: const Text("Technician Chat", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18)),
              ),
            ),
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.chat_bubble_outline, size: 64, color: Colors.grey),
                    const SizedBox(height: 16),
                    const Text('No active job to chat about', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87)),
                    const SizedBox(height: 8),
                    const Text('Long press on the "Technician Chat" title above to seed test data (Debug Mode).', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: Colors.grey)),
                    const SizedBox(height: 24),
                    ElevatedButton(
            onPressed: () => context.read<ChatBloc>().add(LoadChatDataEvent(widget.jobId)),
                      child: const Text('Retry / Refresh'),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        final job = state.job!;
        final customerName = state.customerData?['name'] ?? job.customerName;
        final customerPhone = state.customerData?['phone'];
        final currentUid = FirebaseAuth.instance.currentUser?.uid;

        return Scaffold(
          backgroundColor: const Color(0xFFF8FAFC),
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black, size: 20),
            ),
            title: GestureDetector(
              onLongPress: kDebugMode ? () async {
                await SeedChat.seed();
                if (context.mounted) {
                  context.read<ChatBloc>().add(LoadChatDataEvent(job.id));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Chat Seed Data Loaded Successfully!')),
                  );
                }
              } : null,
              child: const Text(
                "Technician Chat",
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ),
            actions: const [
              Padding(
                padding: EdgeInsets.only(right: 16.0),
                child: CircleAvatar(
                  radius: 18,
                  backgroundColor: Colors.black,
                  child: Icon(Icons.person, color: Colors.white, size: 20),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  controller: _scrollController,
                  reverse: true,
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // Header & Job Card Container
                      buildCustomContainer(
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    const Icon(Icons.person, size: 50),
                                    const SizedBox(width: 8),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              customerName,
                                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                            ),
                                            const SizedBox(width: 8),
                                            buildCustomContainer(
                                              cardColor: AppColors.iconbluebg,
                                              child: const Row(
                                                children: [
                                                  Icon(Icons.verified, size: 12, color: Colors.black),
                                                  SizedBox(width: 4),
                                                  Text(
                                                    'Client',
                                                    style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.w600),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          '${job.customerArea} • Active Job',
                                          style: const TextStyle(fontSize: 11, color: Colors.grey),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                CircleAvatar(
                                  backgroundColor: Colors.blue.shade50,
                                  radius: 22,
                                  child: IconButton(
                                    icon: const Icon(Icons.phone_outlined, color: Colors.blue, size: 20),
                                    onPressed: () => _showCallDialog(customerPhone),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            // Job Card
                            buildCustomContainer(
                              cardColor: AppColors.bluenewcontainer,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  buildCustomContainer(
                                    cardColor: AppColors.iconbluebg,
                                    child: const Icon(Icons.handyman, size: 30, color: Colors.blue),
                                  ),
                                  const SizedBox(width: 6),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              job.requestNumber,
                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.black87),
                                            ),
                                            const SizedBox(width: 6),
                                            Container(width: 6, height: 6, decoration: const BoxDecoration(color: Colors.blue, shape: BoxShape.circle)),
                                            const SizedBox(width: 6),
                                          Text(
  job.status.replaceAll('_', ' ').toUpperCase(), // شلنا .name خالص
  style: const TextStyle(color: Colors.blue, fontSize: 12, fontWeight: FontWeight.w500),
),
                                          ],
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          job.diagnosisTitle,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                                        ),
                                      ],
                                    ),
                                  ),
                                  OutlinedButton(
                                    onPressed: () {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Coming soon')),
                                      );
                                    },
                                    style: OutlinedButton.styleFrom(
                                      backgroundColor: Colors.white,
                                      side: BorderSide(color: Colors.grey.shade300),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    ),
                                    child: const Text('Job Details →', style: TextStyle(color: Colors.black, fontSize: 12)),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Notice Banner
                      buildCustomContainer(
                        cardColor: AppColors.bluenewcontainer,
                        child: Row(
                          children: const [
                            Icon(Icons.shield_outlined, color: AppColors.primary, size: 20),
                            SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                'Official 7elhaly chat channel. Retain all service updates here for warranty validation & job documentation.',
                                style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Messages List
                      state.messages.isEmpty
                          ? const Padding(
                              padding: EdgeInsets.symmetric(vertical: 32.0),
                              child: Text('No messages yet, say hello', style: TextStyle(color: Colors.grey)),
                            )
                          : ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: state.messages.length,
                              itemBuilder: (context, index) {
                                final msg = state.messages[index];
                                final isMe = msg.senderId == currentUid;
                                final timeStr = intl.DateFormat('h:mm a').format(msg.createdAt);

                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 12.0),
                                  child: Align(
                                    alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        if (!isMe) ...[
                                          const Icon(Icons.person, size: 32),
                                          const SizedBox(width: 6),
                                        ],
                                        Flexible(
                                          child: buildCustomContainer(
                                            cardColor: isMe ? Colors.black : Colors.white,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                if (msg.imageUrl != null && msg.imageUrl!.isNotEmpty) ...[
                                                  ClipRRect(
                                                    borderRadius: BorderRadius.circular(8),
                                                    child: Image.network(
                                                      msg.imageUrl!,
                                                      height: 150,
                                                      width: 250,
                                                      fit: BoxFit.cover,
                                                      errorBuilder: (context, error, stackTrace) => const Text('Failed to load image', style: TextStyle(color: Colors.red)),
                                                    ),
                                                  ),
                                                  const SizedBox(height: 8),
                                                ],
                                                SizedBox(
                                                  width: 230,
                                                  child: Text(
                                                    msg.text,
                                                    style: TextStyle(color: isMe ? Colors.white : Colors.black87, fontSize: 14),
                                                  ),
                                                ),
                                                const SizedBox(height: 4),
                                                Row(
                                                  mainAxisSize: MainAxisSize.min,
                                                  mainAxisAlignment: MainAxisAlignment.end,
                                                  children: [
                                                    Text(
                                                      timeStr,
                                                      style: const TextStyle(color: Colors.grey, fontSize: 10),
                                                    ),
                                                    if (isMe) ...[
                                                      const SizedBox(width: 4),
                                                      Icon(
                                                        Icons.done_all,
                                                        color: msg.readAt != null ? Colors.blue : Colors.grey,
                                                        size: 14,
                                                      ),
                                                    ],
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                      const SizedBox(height: 16),
                      // Quick Status Updates Chips
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: const [
                              Row(
                                children: [
                                  Icon(Icons.flash_on, size: 16, color: Colors.blue),
                                  SizedBox(width: 4),
                                  Text(
                                    'QUICK STATUS UPDATES',
                                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey),
                                  ),
                                ],
                              ),
                              Text('Tap to send', style: TextStyle(fontSize: 11, color: Colors.blue)),
                            ],
                          ),
                          const SizedBox(height: 8),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                ActionChip(
                                  avatar: const Icon(Icons.location_on, size: 16, color: Colors.blue),
                                  label: const Text('I have arrived at the building'),
                                  backgroundColor: AppColors.bluenewcontainer,
                                  onPressed: () {
                                    context.read<ChatBloc>().add(SendMessageEvent(jobId: job.id, text: 'I have arrived at the building'));
                                  },
                                ),
                                const SizedBox(width: 8),
                                ActionChip(
                                  avatar: const Icon(Icons.check_circle, size: 16, color: Colors.blue),
                                  label: const Text('Work completed'),
                                  backgroundColor: AppColors.bluenewcontainer,
                                  onPressed: () {
                                    context.read<ChatBloc>().add(SendMessageEvent(jobId: job.id, text: 'Work completed'));
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              // Bottom Input Bar
              buildCustomContainer(
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.camera_alt_outlined, color: Colors.grey),
                      onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Coming soon'))),
                    ),
                    IconButton(
                      icon: const Icon(Icons.insert_drive_file_outlined, color: Colors.grey),
                      onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Coming soon'))),
                    ),
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        decoration: InputDecoration(
                          hintText: 'Reply to $customerName',
                          hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
                          filled: true,
                          fillColor: AppColors.bluenewcontainer,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(24),
                            borderSide: BorderSide.none,
                          ),
                          suffixIcon: IconButton(
                            icon: const Icon(Icons.mic_none, color: Colors.grey),
                            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Coming soon'))),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    CircleAvatar(
                      backgroundColor: Colors.black,
                      radius: 22,
                      child: IconButton(
                        icon: state.isSending
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                            : const Icon(Icons.send, color: Colors.white, size: 18),
                        onPressed: state.isSending
                            ? null
                            : () {
                                final text = _messageController.text.trim();
                                if (text.isNotEmpty) {
                                  context.read<ChatBloc>().add(SendMessageEvent(jobId: job.id, text: text));
                                  _messageController.clear();
                                  _scrollToBottom();
                                }
                              },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}